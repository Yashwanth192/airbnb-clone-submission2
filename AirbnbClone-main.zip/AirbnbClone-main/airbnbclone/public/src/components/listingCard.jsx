import React from "react";

const listingCard = () => {
  return <div>listingCard</div>;
};

export default listingCard;
