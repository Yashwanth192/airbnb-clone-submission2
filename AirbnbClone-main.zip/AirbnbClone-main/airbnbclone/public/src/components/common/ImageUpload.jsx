import React from "react";

const ImageUpload = () => {
  return <div>ImageUpload</div>;
};

export default ImageUpload;
