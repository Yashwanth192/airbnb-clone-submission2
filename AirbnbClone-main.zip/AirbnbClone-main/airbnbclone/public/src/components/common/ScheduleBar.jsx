import React from "react";

const ScheduleBar = () => {
  return <div>ScheduleBar</div>;
};

export default ScheduleBar;
