import React from "react";

const ContextMenu = () => {
  return <div>ContextMenu</div>;
};

export default ContextMenu;
