import React from "react";

const FormInput = () => {
  return <div>FormInput</div>;
};

export default FormInput;
