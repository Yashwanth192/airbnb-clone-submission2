import React from "react";

const Spinner = () => {
  return <div>Spinner</div>;
};

export default Spinner;
