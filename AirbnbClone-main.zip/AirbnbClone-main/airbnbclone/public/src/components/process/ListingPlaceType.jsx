import React from "react";

const ListingPlaceType = () => {
  return <div>ListingPlaceType</div>;
};

export default ListingPlaceType;
