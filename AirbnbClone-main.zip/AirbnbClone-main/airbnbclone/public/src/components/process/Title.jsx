import React from "react";

const Title = () => {
  return <div>Title</div>;
};

export default Title;
