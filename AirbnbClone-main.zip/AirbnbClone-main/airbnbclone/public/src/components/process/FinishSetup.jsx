import React from "react";

const FinishSetup = () => {
  return <div>FinishSetup</div>;
};

export default FinishSetup;
