import React from "react";

const PlaceLocation = () => {
  return <div>PlaceLocation</div>;
};

export default PlaceLocation;
