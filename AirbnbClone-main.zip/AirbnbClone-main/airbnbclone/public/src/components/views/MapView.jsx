import React from "react";

const MapView = () => {
  return <div>MapView</div>;
};

export default MapView;
