import React from "react";

const CompactFooter = () => {
  return <div>CompactFooter</div>;
};

export default CompactFooter;
