import React from "react";

const TripScheduler = () => {
  return <div>TripScheduler</div>;
};

export default TripScheduler;
