export enum EnumSecretsNameKey {
    JwtSecretKey = "JWT_SECRET_KEY"
}