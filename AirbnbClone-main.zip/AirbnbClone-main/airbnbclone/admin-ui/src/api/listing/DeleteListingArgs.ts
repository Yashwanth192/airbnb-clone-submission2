import { ListingWhereUniqueInput } from "./ListingWhereUniqueInput";

export type DeleteListingArgs = {
  where: ListingWhereUniqueInput;
};
