import { ListingWhereUniqueInput } from "./ListingWhereUniqueInput";

export type ListingFindUniqueArgs = {
  where: ListingWhereUniqueInput;
};
