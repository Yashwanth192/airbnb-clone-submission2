import { TripWhereUniqueInput } from "../trip/TripWhereUniqueInput";

export type TripCreateNestedManyWithoutListingsInput = {
  connect?: Array<TripWhereUniqueInput>;
};
