export type ListingWhereUniqueInput = {
  id: string;
};
