import { ListingCreateInput } from "./ListingCreateInput";

export type CreateListingArgs = {
  data: ListingCreateInput;
};
