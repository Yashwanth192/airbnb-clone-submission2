import { WishlistWhereUniqueInput } from "../wishlist/WishlistWhereUniqueInput";

export type WishlistCreateNestedManyWithoutListingsInput = {
  connect?: Array<WishlistWhereUniqueInput>;
};
