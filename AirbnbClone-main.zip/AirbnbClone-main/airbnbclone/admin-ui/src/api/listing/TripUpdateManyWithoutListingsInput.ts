import { TripWhereUniqueInput } from "../trip/TripWhereUniqueInput";

export type TripUpdateManyWithoutListingsInput = {
  connect?: Array<TripWhereUniqueInput>;
  disconnect?: Array<TripWhereUniqueInput>;
  set?: Array<TripWhereUniqueInput>;
};
