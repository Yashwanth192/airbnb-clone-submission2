import { ListingWhereInput } from "./ListingWhereInput";

export type ListingListRelationFilter = {
  every?: ListingWhereInput;
  some?: ListingWhereInput;
  none?: ListingWhereInput;
};
