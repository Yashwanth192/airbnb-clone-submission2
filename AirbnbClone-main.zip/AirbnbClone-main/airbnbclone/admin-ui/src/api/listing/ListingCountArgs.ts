import { ListingWhereInput } from "./ListingWhereInput";

export type ListingCountArgs = {
  where?: ListingWhereInput;
};
