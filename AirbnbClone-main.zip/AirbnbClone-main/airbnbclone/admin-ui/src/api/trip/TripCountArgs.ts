import { TripWhereInput } from "./TripWhereInput";

export type TripCountArgs = {
  where?: TripWhereInput;
};
