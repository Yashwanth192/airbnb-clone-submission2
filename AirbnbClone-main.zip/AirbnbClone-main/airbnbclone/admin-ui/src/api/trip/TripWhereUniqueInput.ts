export type TripWhereUniqueInput = {
  id: string;
};
