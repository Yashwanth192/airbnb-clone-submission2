import { TripCreateInput } from "./TripCreateInput";

export type CreateTripArgs = {
  data: TripCreateInput;
};
