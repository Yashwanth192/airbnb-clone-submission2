import { TripWhereUniqueInput } from "./TripWhereUniqueInput";

export type TripFindUniqueArgs = {
  where: TripWhereUniqueInput;
};
