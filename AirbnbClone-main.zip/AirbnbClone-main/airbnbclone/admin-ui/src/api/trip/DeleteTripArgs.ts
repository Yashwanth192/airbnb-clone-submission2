import { TripWhereUniqueInput } from "./TripWhereUniqueInput";

export type DeleteTripArgs = {
  where: TripWhereUniqueInput;
};
