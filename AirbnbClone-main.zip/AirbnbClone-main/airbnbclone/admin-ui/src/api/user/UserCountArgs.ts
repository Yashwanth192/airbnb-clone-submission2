import { UserWhereInput } from "./UserWhereInput";

export type UserCountArgs = {
  where?: UserWhereInput;
};
