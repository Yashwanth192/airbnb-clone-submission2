import { WishlistWhereUniqueInput } from "../wishlist/WishlistWhereUniqueInput";

export type WishlistCreateNestedManyWithoutUsersInput = {
  connect?: Array<WishlistWhereUniqueInput>;
};
