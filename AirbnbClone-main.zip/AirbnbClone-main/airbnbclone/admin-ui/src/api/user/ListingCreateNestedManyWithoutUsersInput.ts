import { ListingWhereUniqueInput } from "../listing/ListingWhereUniqueInput";

export type ListingCreateNestedManyWithoutUsersInput = {
  connect?: Array<ListingWhereUniqueInput>;
};
