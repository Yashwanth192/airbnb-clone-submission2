import { TripWhereUniqueInput } from "../trip/TripWhereUniqueInput";

export type TripCreateNestedManyWithoutUsersInput = {
  connect?: Array<TripWhereUniqueInput>;
};
