import { UserCreateInput } from "./UserCreateInput";

export type CreateUserArgs = {
  data: UserCreateInput;
};
