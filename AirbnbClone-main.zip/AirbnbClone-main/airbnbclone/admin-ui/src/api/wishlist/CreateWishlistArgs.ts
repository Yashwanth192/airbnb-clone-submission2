import { WishlistCreateInput } from "./WishlistCreateInput";

export type CreateWishlistArgs = {
  data: WishlistCreateInput;
};
