import { WishlistWhereInput } from "./WishlistWhereInput";

export type WishlistListRelationFilter = {
  every?: WishlistWhereInput;
  some?: WishlistWhereInput;
  none?: WishlistWhereInput;
};
