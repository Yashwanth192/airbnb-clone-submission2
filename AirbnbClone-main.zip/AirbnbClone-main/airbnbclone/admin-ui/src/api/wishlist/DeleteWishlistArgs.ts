import { WishlistWhereUniqueInput } from "./WishlistWhereUniqueInput";

export type DeleteWishlistArgs = {
  where: WishlistWhereUniqueInput;
};
