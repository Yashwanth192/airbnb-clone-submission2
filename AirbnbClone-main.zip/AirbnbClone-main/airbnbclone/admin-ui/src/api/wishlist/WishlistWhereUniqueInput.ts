export type WishlistWhereUniqueInput = {
  id: string;
};
