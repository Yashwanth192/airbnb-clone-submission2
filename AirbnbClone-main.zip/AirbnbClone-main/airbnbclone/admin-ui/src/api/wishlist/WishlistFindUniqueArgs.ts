import { WishlistWhereUniqueInput } from "./WishlistWhereUniqueInput";

export type WishlistFindUniqueArgs = {
  where: WishlistWhereUniqueInput;
};
