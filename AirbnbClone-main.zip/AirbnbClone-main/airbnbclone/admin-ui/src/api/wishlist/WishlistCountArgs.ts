import { WishlistWhereInput } from "./WishlistWhereInput";

export type WishlistCountArgs = {
  where?: WishlistWhereInput;
};
