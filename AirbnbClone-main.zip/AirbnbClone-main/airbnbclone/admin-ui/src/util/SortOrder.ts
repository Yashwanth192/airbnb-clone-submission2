export enum SortOrder {
  Asc = "asc",
  Desc = "desc",
}
